drop schema if exists AlmaLaborisSuite;
create schema AlmaLaborisSuite;
use AlmaLaborisSuite;

create table als_utente(
email			varchar(50)		not null,
pw				varchar(200)	not null,
ruolo			varchar(30)		not null,
nome			varchar(30)     not null,
cognome			varchar(30)		not null,
telefono		varchar(10)		not null,
indirizzo		varchar(50),
cap				varchar(10),
citta			varchar(50),
provincia		varchar(50),
data_nascita	varchar(20),
note			blob,

primary key(email)
);

create table als_sede(
id							integer			not null	auto_increment,
nome						varchar(50) 	not null,
riferimento					varchar(50),
indirizzo					varchar(50)		not null,
cap							varchar(10)		not null,
citta						varchar(50)     not null,

primary key(id)
);

create table als_settore(
id				integer 		not null	auto_increment,
nome			varchar(100)	not null,

primary key(id)
);

create table als_master(
id				integer			not null	auto_increment,
nome			varchar(300)	not null,
tag				varchar(100)	not null,
id_settore		integer 		not null,

primary key(id),
foreign key(id_settore) references als_settore(id)
);

create table als_aula(
id							integer				not null	auto_increment,
nome						varchar(50),
piano						varchar(50),
id_sede						integer 			not null,

primary key(id),
foreign key(id_sede) references als_sede(id)
);

create table als_edizione(
id					integer 		not null	auto_increment,
nome				varchar(100)	not null,
data_invio_scheda	varchar(20),
data_inizio			varchar(20)		not null,
data_fine			varchar(20) 	not null,
inizio_vf			varchar(20),
fine_vf				varchar(20),
id_master			integer			not null,
id_aula				integer			not null,

primary key(id),
foreign key(id_master) references als_master(id),
foreign key(id_aula) references als_aula(id)
);

create table als_stato(
email						varchar(50)		not null,
id_edizione					integer			not null,
interessato					boolean,
info_specifica				boolean,
info_generica				boolean,
contattato					boolean,
prenotazione_colloquio      boolean,
attesa_data_selezione		boolean,
presenza_selezione			boolean,
attesa_esito_selezione		boolean,
ammesso						boolean,
scheda_iscrizione_inviata	boolean,
scheda_iscrizione_approvata boolean,
iscritto					boolean,
quietanza1_inviata			boolean,
quietanza2_inviata			boolean,
quietanza3_inviata			boolean,
quietanza1_pagata			boolean,
quietanza2_pagata			boolean,
quietanza3_pagata			boolean,

primary key(email, id_edizione),
foreign key(email) references als_utente(email),
foreign key(id_edizione) references als_edizione(id)
);

create table als_candidato(
email 						varchar(50)		not null,
id_master					integer			not null,
data_inserimento			timestamp       DEFAULT CURRENT_TIMESTAMP,
fonte						varchar(100)	not null,
format_scelto				varchar(30),
cv							varchar(300),
scheda_iscrizione			varchar(300),
quietanza1					varchar(300),

primary key(email,id_master),
foreign key(email) references als_utente(email),
foreign key(id_master) references als_master(id)
);

create table als_partecipante(
email 						varchar(50)		not null,
id_edizione					integer			not null,
data_inserimento			timestamp       DEFAULT CURRENT_TIMESTAMP,
fonte						varchar(100)	not null,
format_scelto				varchar(30)		not null,
cv							varchar(300)	not null,
scheda_iscrizione			varchar(300)	not null,
quietanza1					varchar(300)	not null,
quietanza2					varchar(300),
quietanza3					varchar(300),

primary key(email,id_edizione),
foreign key(email) references als_utente(email),
foreign key(id_edizione) references als_edizione(id)
);

create table als_operatore_tecnico(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_direzione(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_segreteria(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_frontoffice(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_dataentry(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_advertiser(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_selezionatore(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_content(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_chiamata(
id							integer 			not null	auto_increment,
utente						varchar(50) 		not null,
operatore					varchar(50)			not null,
data_chiamata				varchar(20)			not null,
motivo						varchar(200)		not null,
tipo						varchar(11),

primary key(id),
foreign key(utente) references als_utente(email),
foreign key(operatore)	references als_utente(email)
);

create table als_colloquio(
id							integer				not null	auto_increment,
utente						varchar(50)			not null,
data_inizio					varchar(20)			not null,
data_fine					varchar(20)			not null,
tipo						varchar(100)		not null,
id_sede						integer,

primary key(id),
foreign key(utente) references als_utente(email),
foreign key(id_sede) references als_sede(id)
);als_utente

/* SPECCHIO STRUTTURA DB

1)  CAMPI TABELLA als_utente
    email | pw | ruolo | nome | cognome | telefono | indirizzo
    cap | citta | provincia | data_nascita | blob
   
2)  CAMPI TABELLA als_sede
    id | nome | riferimento | indirizzo | cap | citta
   
3)  CAMPI TABELLA als_settore
    id | nome
   
4)  CAMPI TABELLA als_master
    id | nome | tag | id_settore

5)  CAMPI TABELLA als_aula
    id | nome | piano | id_sede
   
6)  CAMPI TABELLA als_edizione
    id | nome | data_invio_scheda | data_inizio | data_fine 
    inizio_vf | fine_vf | id_master | id_aula

7)  CAMPI TABELLA als_stato
    email | id_edizione | interessato | info_specifica | info_generica | contattato | prenotazione_colloquio 
    attesa_data_selezione | presenza_selezione | attesa_esito_selezione | ammesso | scheda_iscrizione_inviata | 
    scheda_iscrizione_approvata | iscritto | quietanza1_inviata | quietanza2_inviata | quietanza3_inviata 
    quietanza1_pagata | quietanza2_pagata | quietanza3_pagata

8)  CAMPI TABELLA als_candidato
    email | id_master | data_inserimento | fonte
    format_scelto | cv | scheda_iscrizione | quietanza1
   
9)  CAMPI TABELLA als_partecipante
    email | id_edizione | data_inserimento | fonte | format_scelto | cv 
    scheda_iscrizione | quietanza1 | quietanza2 | quietanza3
   
10) CAMPI TABELLA als_operatore tecnico
    email

11) CAMPI TABELLA als_operatore_direzione
    email
    
12) CAMPI TABELLA als_operatore_segreteria
    email
    
13) CAMPI TABELLA als_operatore_frontoffice
	email
 
14) CAMPI TABELLA als_operatore_dataentry
    email
    
15) CAMPI TABELLA als_operatore_advertiser
    email
    
16) CAMPI TABELLA als_operatore_selezionatore
    email

17) CAMPI TABELLA als_operatore_content
    email

18) CAMPI TABELLA als_chiamata
	id | utente | operatore | data_chiamata | motivo | tipo

20) CAMPI TABELLA als_colloquio
	id | utente | data_inizio | data_fine | tipo | id_sede
*/
/*
AGGIUNTE
1) stato prenotazione_colloquio in tabella als_stato
*/