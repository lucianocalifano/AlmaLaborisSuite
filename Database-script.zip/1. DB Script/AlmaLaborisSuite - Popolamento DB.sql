drop schema if exists AlmaLaborisSuite;
create schema AlmaLaborisSuite;
use AlmaLaborisSuite;

create table als_utente(
email			varchar(50)		not null,
pw				varchar(200)	not null,
ruolo			varchar(30)		not null,
nome			varchar(30)     not null,
cognome			varchar(30)		not null,
telefono		varchar(10)		not null,
indirizzo		varchar(50),
cap				varchar(10),
citta			varchar(50),
provincia		varchar(50),
data_nascita	varchar(20),
note			blob,

primary key(email)
);

create table als_sede(
id							integer			not null	auto_increment,
nome						varchar(50) 	not null,
riferimento					varchar(50),
indirizzo					varchar(50)		not null,
cap							varchar(10)		not null,
citta						varchar(50)     not null,

primary key(id)
);

create table als_settore(
id				integer 		not null	auto_increment,
nome			varchar(100)	not null,

primary key(id)
);

create table als_master(
id				integer			not null	auto_increment,
nome			varchar(300)	not null,
tag				varchar(100)	not null,
id_settore		integer 		not null,

primary key(id),
foreign key(id_settore) references als_settore(id)
);

create table als_aula(
id							integer				not null	auto_increment,
nome						varchar(50),
piano						varchar(50),
id_sede						integer 			not null,

primary key(id),
foreign key(id_sede) references als_sede(id)
);

create table als_edizione(
id					integer 		not null	auto_increment,
nome				varchar(100)	not null,
data_invio_scheda	varchar(20),
data_inizio			varchar(20),
data_fine			varchar(20),
inizio_vf			varchar(20),
fine_vf				varchar(20),
id_master			integer			not null,
id_aula				integer			not null,

primary key(id),
foreign key(id_master) references als_master(id),
foreign key(id_aula) references als_aula(id)
);

create table als_stato(
email						varchar(50)		not null,
edizione					varchar(100)	not null,
id_master					integer			not null,
interessato					boolean,
info_specifica				boolean,
info_generica				boolean,
contattato					boolean,
prenotazione_colloquio      boolean,
attesa_data_selezione		boolean,
presenza_selezione			boolean,
attesa_esito_selezione		boolean,
ammesso						boolean,
scheda_iscrizione_inviata	boolean,
scheda_iscrizione_approvata boolean,
iscritto					boolean,
quietanza1_inviata			boolean,
quietanza2_inviata			boolean,
quietanza3_inviata			boolean,
quietanza1_pagata			boolean,
quietanza2_pagata			boolean,
quietanza3_pagata			boolean,

primary key(email, edizione, id_master),
foreign key(email) references als_utente(email),
foreign key(id_master) references als_master(id)
);

create table als_candidato(
email 						varchar(50)		not null,
id_master					integer			not null,
data_inserimento			timestamp       DEFAULT CURRENT_TIMESTAMP,
fonte						varchar(100)	not null,
format_scelto				varchar(30),
cv							varchar(300),
scheda_iscrizione			varchar(300),
quietanza1					varchar(300),

primary key(email,id_master),
foreign key(email) references als_utente(email),
foreign key(id_master) references als_master(id)
);

create table als_partecipante(
email 						varchar(50)		not null,
id_edizione					integer			not null,
data_inserimento			timestamp       DEFAULT CURRENT_TIMESTAMP,
fonte						varchar(100)	not null,
format_scelto				varchar(30)		not null,
cv							varchar(300)	not null,
scheda_iscrizione			varchar(300)	not null,
quietanza1					varchar(300)	not null,
quietanza2					varchar(300),
quietanza3					varchar(300),

primary key(email,id_edizione),
foreign key(email) references als_utente(email),
foreign key(id_edizione) references als_edizione(id)
);

create table als_operatore_tecnico(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_direzione(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_segreteria(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_frontoffice(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_dataentry(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_advertiser(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_selezionatore(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_operatore_content(
email						varchar(50)		not null,

primary key(email),
foreign key(email) references als_utente(email)
);

create table als_chiamata(
id							integer 			not null	auto_increment,
utente						varchar(50) 		not null,
operatore					varchar(50)			not null,
data_chiamata				varchar(20)			not null,
motivo						varchar(200)		not null,
tipo						varchar(11),

primary key(id),
foreign key(utente) references als_utente(email),
foreign key(operatore)	references als_utente(email)
);

create table als_colloquio(
id							integer				not null	auto_increment,
utente						varchar(50)			not null,
data_inizio					varchar(20)			not null,
data_fine					varchar(20)			not null,
tipo						varchar(100)		not null,
id_sede						integer,

primary key(id),
foreign key(utente) references als_utente(email),
foreign key(id_sede) references als_sede(id)
);

/* 
DATAENTRY, FRONOFFICE, SEGRETERIA, SELEZIONATORE, CONTENT, ADVERTISER, TECNICO, DIREZIONE, CANDIDATO, PARTECIPANTE
*/ 

INSERT INTO als_utente 
VALUES ('adv.content@almalaboris.com', 'content@123','CONTENT','Marco','Stile','3332211555','via Nazionale 45','84010','Pagani','SA','2020-05-16 15:00:01', null),
	   ('segreteria@almalaboris.it', 'segreteria@123','SEGRETERIA','Marina','Sessa','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('amministrativo@almalaboris.com', 'direzione@123','DIREZIONE','Dario','Numeroso','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
	   ('ernesto.sparalesto@almalaboris.com', 'direzione@123','DIREZIONE','Ernesto','Sparalesto','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
	   ('vincenzo.pepe@almalaboris.com', 'tecnico@123','TECNICO','Vincenzo','Pepe','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
	   ('luciano.califano@almalaboris.com', 'tecnico@123','TECNICO','Dario','Numeroso','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('giuliana.gaudiosi@almalaboris.com', 'selezionatore@123','SELEZIONATORE','Giuliana','Gaudiosi','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
	   ('carmine.palermo@almalaboris.com', 'selezionatore@123','SELEZIONATORE','Carmine','Palermo','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('frontoffice@almalaboris.com', 'frontoffice@123','FRONTOFFICE','Maurizio','Del Gaudio','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('annalisa.dammacco@almalaboris.com', 'dataentry@123','DATAENTRY','Annalisa','Dammacco','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('advertiser@almalaboris.com', 'advertiser@123','ADVERTISER','Francesco','Fantasia','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('mario.rossi@gmail.com', 'mrossi@123','CANDIDATO','Mario','Rossi','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('marina.pilastro@gmail.com', 'mpilastro@123','CANDIDATO','Marina','Pilastro','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('giuliana.radice@gmail.com', 'gradice@123','CANDIDATO','Giulina','Radice','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Carlo.botteon@gmail.com', 'cbotteon@123','CANDIDATO','Carlo','Botteon','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Anna.Sernicola@gmail.com', 'asernicola@123','CANDIDATO','Anna','Sernicola','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('elena.bisola@gmail.com', 'ebisola@123','CANDIDATO','Elena','Bisola','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('maria.tridente@gmail.com', 'mtridente@123','CANDIDATO','Maria','Tridente','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Piero.maltro@gmail.com', 'pmaltro@123','CANDIDATO','Piero','Maltro','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Paolo.regalia@gmail.com', 'pregalia@123','CANDIDATO','Paolo','Regalia','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Manuel.cistana@gmail.com', 'mcistana@123','CANDIDATO','Manuel','Cistana','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('guido.bianchi@gmail.com', 'gbianchi@123','PARTECIPANTE','Guido','Bianchi','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('ludovico.enaudi@gmail.com', 'lenaudi@123','PARTECIPANTE','Ludovico','Enaudi','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Daniele.siniscalchi@gmail.com', 'dsiniscalchi@123','PARTECIPANTE','Daniele','Siniscalchi','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Valentino.pernom@gmail.com', 'vpernom@123','PARTECIPANTE','Valentino','Pernom','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Michele.bosco@gmail.com', 'mbosco@123','PARTECIPANTE','Michele','Bosco','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Antonio.persico@gmail.com', 'apersico@123','PARTECIPANTE','Antonio','Persico','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Ernesto.medito@gmail.com', 'emedito@123','PARTECIPANTE','Ernesto','Medito','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Pasquale.pistoia@gmail.com', 'ppistoia@123','PARTECIPANTE','Pasquale','Pistoia','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Leonardo.venditti@gmail.com', 'lvenditti@123','PARTECIPANTE','Leonardo','Venditti','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null),
       ('Tiziano.cartone@gmail.com', 'tcartone@123','PARTECIPANTE','Tiziano','Cartone','3332211555','via Nazionale 45','84010','Pagani','SA', '2020-05-16 15:00:01', null);

INSERT INTO als_sede(nome, riferimento, indirizzo, cap, citta) 
VALUES ('Polo Didattico Milano', 'Centro Congressi Cantoni', 'Via Giovanni Cantoni, 7', '20144','Milano'),
	   ('Polo Didattico Napoli', 'Tiempo Business Center', 'Centro Direzionale Isola E5 Scala A', '80143','Napoli'),
	   ('Polo Didattico Roma', 'Alma Laboris Academy', 'Piazza Delle Cinque Scole 23', '00186','Roma'),
	   ('Polo Didattico Padova', 'Istituto di Cultura Italo-Tedesco', 'Via Borromeo, 16', '35137','Padova'),
	   ('Polo Didattico Torino', 'Tiempo Business Center', 'Corso Vittorio Emanuele II, 104', '10121','Torino'),
       ('Polo Didattico Bologna', 'SAVHOTEL', 'Via F. Parri, 9', '40121','Bologna'),
       ('Polo Didattico Bari', 'Villa Romanazzi Carducci', 'Via Giuseppe Capruzzi, 326', '70124','Bari'),
       ('Polo Didattico Online', 'SkyMeeting','invito skymeeting','00000','Internet');

INSERT INTO als_settore(nome)
VALUES ('Risorse Umane'),
	   ('Export'),
	   ('Farmaceutico'),
	   ('Legale'),
	   ('Sistemi di Gestione Integrati'),
	   ('Energia'),
	   ('Ambientale'),
	   ('Project Management'),
	   ('Digital'),
	   ('Tributario'),
	   ('Finanza');

INSERT INTO als_master(nome, tag, id_settore)
VALUES ('Gestione, Sviluppo e Amministrazione delle Risorse Umane','Risorse',1),
	   ('Energy Management','Energy',6),
	   ('Export Management: Commercio Internazionale e Nuovi Mercati','Export',2),
	   ('Giuristi d\'Impresa','Giuristi',4),
	   ('Sistemi di Gestione Integrati per la Qualità, Sicurezza, Energia e Ambiente','Sistemi',5),
	   ('Amministrazione del Personale e Consulenza del Lavoro','Amministrazione',1),
	   ('Management e Marketing dell\'Industria Farmaceutica','Farma',3),
	   ('Digital Marketing & Omnichannel Strategy Management','Digital',9),
	   ('Management dell\'Ambiente','Ambiente',7),
	   ('Legal Advisor: il Responsabile della Compliance Aziendale','Legal',4),
	   ('Trade Finance: Pagamenti e Strumenti per il Commercio Estero','Trade',2),
       ('Project Management','Project',8),
       ('Pharma Medical Affairs','Medical',3),
       ('Diritto Tributario','Tributario',4),
       ('Finanza e Controllo di Gestione: Budgeting, Reporting e Analisi','Finanza',11);

INSERT INTO als_aula(nome, piano, id_sede)
VALUES ('Aula 1','Secondo Piano',1), /* aule milano */
	   ('Aula 2','Primo Piano',1),
	   ('Aula 1','Secondo Piano',2), /* aule napoli */
	   ('Aula 2','Primo Piano',2),
       ('Aula 1','Secondo Piano',3), /* aule roma */
	   ('Aula 2','Primo Piano',3),
	   ('Aula 1','Secondo Piano',4), /* padova */
	   ('Aula 2','Primo Piano',4),
	   ('Aula 1','Secondo Piano',5), /* torino */
	   ('Aula 2','Primo Piano',5),
       ('Aula 1','Secondo Piano',6), /* bologna */
	   ('Aula 2','Primo Piano',6),
       ('Aula 1','Secondo Piano',7), /* bari */
	   ('Aula 2','Primo Piano',7),
       ('Aula Digitale','Online',8);/* online */

/*
EDIZIONI: 1 - 2 - 4 - 3 (online) - 10 - 13 - 6 - 11 - 7 - 9 (aula)
AULA: 1 (aula 1 milano) - 3 (aula 1 napoli) - 5 (aula 1 roma) - 7 (aula 1 padova) - 15 (aula digitale ) 
*/
INSERT INTO als_edizione(nome, data_invio_scheda, data_inizio, data_fine, inizio_vf, fine_vf, id_master, id_aula)
VALUES ('MARZO 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',1,15),
	   ('MARZO 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',2,15),
	   ('MARZO 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',3,15),
	   ('MARZO 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',4,15),      
       ('MARZO 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',15,15),
	   ('OTTOBRE 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',1,3),
	   ('OTTOBRE 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',2,1),
	   ('OTTOBRE 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',1,7),
	   ('OTTOBRE 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',2,5),
	   ('OTTOBRE 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',3,3),
	   ('NOVEMBRE 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',1,1),
	   ('NOVEMBRE 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',2,7),
	   ('NOVEMBRE 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',3,5),
	   ('NOVEMBRE 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',2,3),
	   ('NOVEMBRE 2020', '2021-02-01 13:30:00', '2021-01-01 00:00:00','2021-06-01 00:00:00','2021-05-25 09:30:00','2021-05-25 11:00:00',3,1);

INSERT INTO als_stato VALUES ('mario.rossi@gmail.com'			, 'MARZO 2021', 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
							 ('marina.pilastro@gmail.com'		, 'MARZO 2021', 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                             ('giuliana.radice@gmail.com'		, 'MARZO 2021', 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
							 ('Carlo.botteon@gmail.com'			, 'MARZO 2021', 2, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
							 ('Anna.Sernicola@gmail.com'		, 'MARZO 2021', 15, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                             ('Anna.Sernicola@gmail.com'		, 'MARZO 2021', 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                             ('Anna.Sernicola@gmail.com'		, 'MARZO 2021', 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                             ('elena.bisola@gmail.com'			, 'MARZO 2021', 15, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                             ('maria.tridente@gmail.com'		, 'MARZO 2021', 4, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                             ('Piero.maltro@gmail.com'			, 'MARZO 2021', 4, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                             ('Paolo.regalia@gmail.com'			, 'MARZO 2021', 3, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
                             ('Manuel.cistana@gmail.com'		, 'MARZO 2021', 3, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), /* CANDIDATO */
							 ('guido.bianchi@gmail.com'			, 'MARZO 2020', 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0),
							 ('ludovico.enaudi@gmail.com'		, 'MARZO 2020', 2, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0),
                             ('Daniele.siniscalchi@gmail.com'	, 'MARZO 2020', 4, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0),
                             ('Valentino.pernom@gmail.com'		, 'MARZO 2020', 3, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0),
                             ('Michele.bosco@gmail.com'			, 'OTTOBRE 2020', 3, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0),
                             ('Antonio.persico@gmail.com'		, 'NOVEMBRE 2020', 3, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0),
                             ('Ernesto.medito@gmail.com'		, 'OTTOBRE 2020', 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0),
                             ('Pasquale.pistoia@gmail.com'		, 'NOVEMBRE 2020', 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0),
                             ('Leonardo.venditti@gmail.com'		, 'OTTOBRE 2020', 2, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0),
                             ('Tiziano.cartone@gmail.com'		, 'OTTOBRE 2020', 2, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0); /* PARTECIPANTI */
                             
INSERT INTO als_candidato(email, id_master, fonte, format_scelto, cv, scheda_iscrizione, quietanza1) 
VALUES ('mario.rossi@gmail.com', 1, 'LINKEDIN', 'AULA', '', '', ''),
	   ('marina.pilastro@gmail.com', 1, 'LINKEDIN', 'ONLINE', '', '', ''),
       ('giuliana.radice@gmail.com', 2, 'SITO', 'AULA', '', '', ''),
       ('Carlo.botteon@gmail.com', 2, 'LINKEDIN', 'ONLINE', '', '', ''),
	   ('Anna.Sernicola@gmail.com', 15, 'LINKEDIN', 'AULA', '', '', ''),
       ('Anna.Sernicola@gmail.com', 4, 'LINKEDIN', 'AULA', '', '', ''),
       ('Anna.Sernicola@gmail.com', 1, 'LINKEDIN', 'AULA', '', '', ''),
       ('elena.bisola@gmail.com', 15, 'LINKEDIN', 'ONLINE', '', '', ''),
       ('maria.tridente@gmail.com', 4, 'LINKEDIN', 'AULA', '', '', ''),
	   ('Piero.maltro@gmail.com', 4, 'LINKEDIN', 'ONLINE', '', '', ''),
	   ('Paolo.regalia@gmail.com', 3, 'LINKEDIN', 'AULA', '', '', ''),
	   ('Manuel.cistana@gmail.com', 3, 'LINKEDIN', 'ONLINE', '', '', '');

INSERT INTO als_partecipante(email, id_edizione, fonte, format_scelto, cv, scheda_iscrizione, quietanza1, quietanza2, quietanza3)
VALUES ('guido.bianchi@gmail.com', 1, 'LINKEDIN', 'ONLINE', '','','','',''),
	   ('ludovico.enaudi@gmail.com',2, 'LINKEDIN','ONLINE', '','','','',''),
	   ('Daniele.siniscalchi@gmail.com',4, 'LINKEDIN','ONLINE', '','','','',''), /* MARZO 2020 */
	   ('Valentino.pernom@gmail.com',3, 'LINKEDIN','ONLINE','','','','',''),
	   ('Michele.bosco@gmail.com',10, 'LINKEDIN','AULA','','','','',''),
       ('Antonio.persico@gmail.com',13, 'LINKEDIN','AULA','','','','',''),
       ('Ernesto.medito@gmail.com',6, 'LINKEDIN','AULA','','','','',''),
       ('Pasquale.pistoia@gmail.com',11, 'LINKEDIN','AULA','','','','',''),
       ('Leonardo.venditti@gmail.com',7, 'LINKEDIN','AULA','','','','',''),
       ('Tiziano.cartone@gmail.com',9, 'LINKEDIN','AULA','','','','','');

INSERT INTO als_operatore_tecnico VALUES ('vincenzo.pepe@almalaboris.com'),
							             ('luciano.califano@almalaboris.com');

INSERT INTO als_operatore_direzione VALUES('amministrativo@almalaboris.com'),
										  ('ernesto.sparalesto@almalaboris.com');

INSERT INTO als_operatore_dataentry VALUES('annalisa.dammacco@almalaboris.com');

INSERT INTO als_operatore_frontoffice VALUES('frontoffice@almalaboris.com');

INSERT INTO als_operatore_segreteria VALUES('segreteria@almalaboris.it');

INSERT INTO als_operatore_advertiser VALUES('advertiser@almalaboris.com');

INSERT INTO als_operatore_content VALUES('adv.content@almalaboris.com');

INSERT INTO als_operatore_selezionatore VALUES('giuliana.gaudiosi@almalaboris.com'),
											  ('carmine.palermo@almalaboris.com');

/*
18) CAMPI TABELLA als_chiamata
	id | utente | operatore | data_chiamata | motivo | tipo

20) CAMPI TABELLA als_colloquio
	id | utente | inizio | fine | tipo | id_sede
*/
/*
--------------------------- MOTIVI CHIAMATA ---------------------------
1) PRIMO CONTATTO: 			 Primo Contatto (senza risposta)
							 Primo Contatto (positivo)
							 Primo Contatto (negativo)
2) CONTATTO PER SELEZIONE:   Info Selezione
							 Conferma Selezione (positivo)
							 Conferma Selezione (negativa)
                             Conferma Selezione (senza risposta)
							 Comunicazione Esito
3) CONTATTO PRE ISCRIZIONE:  Sollecito Iscrizione (negativo)
							 Sollecito Iscrizione (positivo)
                             Sollecito Iscrizione (senza risposta)
							 Problematica Scheda
4) CONTATTO POST ISCRIZIONE: Info Fatturazione
							 Sollecito Pagamento (positivo)
                             Sollecito Pagamento (negativo)
                             Sollecito Pagamento (senza risposta)
5) CONTATTO FINE MASTER:	 Info Stage
							 Comunicazione Stage
*/
INSERT INTO als_chiamata(utente, operatore, data_chiamata, motivo, tipo)
VALUES ('Anna.Sernicola@gmail.com', 'frontoffice@almalaboris.com', '2021-01-10 09:45:00', 'Primo Contatto (negativo)', 'EFFETTUATA'),    /* CANDIDATI NON OK */
	   ('elena.bisola@gmail.com', 'frontoffice@almalaboris.com', '2021-01-10 09:45:00', 'Primo Contatto (positivo)', 'EFFETTUATA'),
       ('elena.bisola@gmail.com', 'frontoffice@almalaboris.com', '2021-01-12 09:20:00', 'Presenza Selezione (negativa)', 'EFFETTUATA'),
	   ('mario.rossi@gmail.com', 'frontoffice@almalaboris.com', '2021-01-10 09:45:00', 'Primo Contatto (positivo)', 'RICEVUTA'),    /* CANDIDATI OK */
	   ('mario.rossi@gmail.com', 'frontoffice@almalaboris.com', '2021-01-10 09:45:00', 'Comunicazione Esito', 'EFFETTUATA'),
       ('mario.rossi@gmail.com', 'frontoffice@almalaboris.com', '2021-01-12 09:20:00', 'Sollecito Iscrizione (senza risposta)', 'EFFETTUATA'),
       ('mario.rossi@gmail.com', 'frontoffice@almalaboris.com', '2021-01-12 15:00:00', 'Sollecito Iscrizione (positivo)', 'EFFETTUATA'),
       ('mario.rossi@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Problematica Scheda', 'EFFETTUATA'),
       ('mario.rossi@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Sollecito Iscrizione (negativo)', 'EFFETTUATA'),
       ('giuliana.radice@gmail.com', 'frontoffice@almalaboris.com', '2021-01-10 09:45:00', 'Primo Contatto (positivo)', 'EFFETTUATA'),
       ('giuliana.radice@gmail.com', 'frontoffice@almalaboris.com', '2021-01-10 09:45:00', 'Info Selezione', 'RICEVUTA'),
	   ('giuliana.radice@gmail.com', 'frontoffice@almalaboris.com', '2021-01-12 09:20:00', 'Comunicazione Esito', 'EFFETTUATA'),
       ('giuliana.radice@gmail.com', 'frontoffice@almalaboris.com', '2021-01-12 15:00:00', 'Sollecito Iscrizione (positiva)', 'EFFETTUATA'),
	   ('Antonio.persico@gmail.com', 'frontoffice@almalaboris.com', '2021-01-10 09:45:00', 'Primo Contatto (positivo)', 'EFFETTUATA'),  /* PARTECIPANTI OK */
	   ('Antonio.persico@gmail.com', 'frontoffice@almalaboris.com', '2021-01-12 09:20:00', 'Info Selezione', 'RICEVUTA'),
       ('Antonio.persico@gmail.com', 'frontoffice@almalaboris.com', '2021-01-12 15:00:00', 'Conferma Selezione (senza risposta)', 'EFFETTUATA'),
       ('Antonio.persico@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Conferma Selezione (senza risposta)', 'EFFETTUATA'),
       ('Antonio.persico@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Conferma Selezione (positivo)', 'EFFETTUATA'),
       ('Antonio.persico@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Comunicazione esito', 'EFFETTUATA'),
       ('Antonio.persico@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Sollecito Iscrizione (senza risposta)', 'EFFETTUATA'),
       ('Antonio.persico@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Sollecito Iscrizione (positivo)', 'EFFETTUATA'),
       ('Antonio.persico@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Problematica Scheda', 'EFFETTUATA'),
       ('Antonio.persico@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Problematica Scheda', 'EFFETTUATA'),
	   ('Antonio.persico@gmail.com', 'giuliana.gaudiosi@almalaboris.com', '2021-01-15 10:15:00', 'Comunicazione Stage', 'EFFETTUATA'),
	   ('Tiziano.cartone@gmail.com', 'frontoffice@almalaboris.com', '2021-01-10 09:45:00', 'Info Svolgimento Master', 'RICEVUTA'),
	   ('Tiziano.cartone@gmail.com', 'frontoffice@almalaboris.com', '2021-01-12 09:20:00', 'Sollecito Iscrizione Senza risposta', 'EFFETTUATA'),
       ('Tiziano.cartone@gmail.com', 'frontoffice@almalaboris.com', '2021-01-12 15:00:00', 'Sollecito Iscrizione Senza risposta', 'EFFETTUATA'),
       ('Tiziano.cartone@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Sollecito Iscrizione', 'EFFETTUATA'),
       ('Tiziano.cartone@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Sollecito Iscrizione', 'EFFETTUATA'),
       ('Tiziano.cartone@gmail.com', 'frontoffice@almalaboris.com', '2021-01-15 10:15:00', 'Problemi Scheda', 'EFFETTUATA'),
       ('Tiziano.cartone@gmail.com', 'segreteria@almalaboris.it', '2021-01-15 10:15:00', 'Sollecito Pagamento', 'EFFETTUATA'),
       ('Tiziano.cartone@gmail.com', 'segreteria@almalaboris.it', '2021-01-15 10:15:00', 'Info Fatturazione', 'RICEVUTA'),
	   ('Tiziano.cartone@gmail.com', 'giuliana.gaudiosi@almalaboris.com', '2021-01-15 10:15:00', 'Comunicazione Stage', 'EFFETTUATA');

/* 20) CAMPI TABELLA als_colloquio
	id | utente | data_inizio | data_fine | tipo | id_sede */
INSERT INTO als_colloquio(utente, data_inizio, data_fine, tipo, id_sede)
VALUES ('elena.bisola@gmail.com', '2021-03-24 09:30:00', '2021-03-24 09:30:00', 'IN PRESENZA', 1),
	   ('giuliana.radice@gmail.com', '2021-03-26 09:30:00', '2021-03-24 09:30:00', 'IN PRESENZA', 6),
       ('Antonio.persico@gmail.com', '2021-03-05 11:00:00', '2021-03-05 11:15:00', 'TELEFONICO', 8),
       ('Tiziano.cartone@gmail.com', '2021-03-10 10:30:00', '2021-03-26 10:45:00', 'TELEFONICO', 8);

/* SPECCHIO STRUTTURA DB

1)  CAMPI TABELLA als_utente
    email | pw | ruolo | nome | cognome | telefono | indirizzo
    cap | citta | provincia | data_nascita | note
   
2)  CAMPI TABELLA als_sede
    id | nome | riferimento | indirizzo | cap | citta
   
3)  CAMPI TABELLA als_settore
    id | nome
   
4)  CAMPI TABELLA als_master
    id | nome | tag | id_settore

5)  CAMPI TABELLA als_aula
    id | nome | piano | id_sede
   
6)  CAMPI TABELLA als_edizione
    id | nome | data_invio_scheda | data_inizio | data_fine 
    inizio_vf | fine_vf | id_master | id_aula

7)  CAMPI TABELLA als_stato
    email | id_edizione | interessato | info_specifica | info_generica | contattato | prenotazione_colloquio 
    attesa_data_selezione | presenza_selezione | attesa_esito_selezione | ammesso | scheda_iscrizione_inviata | 
    scheda_iscrizione_approvata | iscritto | quietanza1_inviata | quietanza2_inviata | quietanza3_inviata 
    quietanza1_pagata | quietanza2_pagata | quietanza3_pagata

8)  CAMPI TABELLA als_candidato
    email | id_master | data_inserimento | fonte
    format_scelto | cv | scheda_iscrizione | quietanza1
   
9)  CAMPI TABELLA als_partecipante
    email | id_edizione | data_inserimento | fonte | format_scelto | cv 
    scheda_iscrizione | quietanza1 | quietanza2 | quietanza3
   
10) CAMPI TABELLA als_operatore tecnico
    email

11) CAMPI TABELLA als_operatore_direzione
    email
    
12) CAMPI TABELLA als_operatore_segreteria
    email
    
13) CAMPI TABELLA als_operatore_frontoffice
	email
 
14) CAMPI TABELLA als_operatore_dataentry
    email
    
15) CAMPI TABELLA als_operatore_advertiser
    email
    
16) CAMPI TABELLA als_operatore_selezionatore
    email

17) CAMPI TABELLA als_operatore_content
    email

18) CAMPI TABELLA als_chiamata
	id | utente | operatore | data_chiamata | motivo | tipo

20) CAMPI TABELLA als_colloquio
	id | utente | data_inizio | data_fine | tipo | id_sede
*/
/*
AGGIUNTE
1) stato prenotazione_colloquio in tabella als_stato
*/